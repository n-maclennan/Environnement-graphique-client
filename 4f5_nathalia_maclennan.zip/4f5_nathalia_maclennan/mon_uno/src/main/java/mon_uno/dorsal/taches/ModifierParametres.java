package mon_uno.dorsal.taches;
import static ca.ntro.app.tasks.backend.BackendTasks.*;

import ca.ntro.app.tasks.backend.BackendTasks;
import mon_uno.commun.messages.MsgAjouterSons;
import mon_uno.commun.messages.MsgRetirerSon;
import mon_uno.commun.modeles.ModeleParametres;



public class ModifierParametres {
	public static void creerTaches(BackendTasks tasks) {

        tasks.taskGroup("ModifierParametres")

             .waitsFor(model(ModeleParametres.class))

             .andContains(subTasks -> {

                // XXX: ajouter l'appel!
                ajouterSons(subTasks);
                
                retirerSons(subTasks);

              });
    }

    private static void retirerSons(BackendTasks subTasks) {
    	subTasks.task("retirerSons")

        .waitsFor(message(MsgRetirerSon.class))
        
        .thenExecutes(inputs -> {

            MsgRetirerSon msgRetirerSons = inputs.get(message(MsgRetirerSon.class));
            ModeleParametres    parametres          = inputs.get(model(ModeleParametres.class));

            msgRetirerSons.retirerDe(parametres);
        });		
	}

	private static void ajouterSons(BackendTasks subTasks) {
        subTasks.task("ajouterSon")

             .waitsFor(message(MsgAjouterSons.class))

             .thenExecutes(inputs -> {

                 MsgAjouterSons msgAjouterSons = inputs.get(message(MsgAjouterSons.class));
                 ModeleParametres    parametres          = inputs.get(model(ModeleParametres.class));

                 // Prêt à ajouter un rendez-vous!
                 msgAjouterSons.ajouterA(parametres);

             });
    }
}
