package mon_uno.dorsal;

import ca.ntro.app.backend.LocalBackendNtro;
import ca.ntro.app.tasks.backend.BackendTasks;
import mon_uno.dorsal.taches.ModifierParametres;

public class DorsalUno extends LocalBackendNtro{

	@Override
	public void createTasks(BackendTasks tasks) {
		ModifierParametres.creerTaches(tasks);
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
