package mon_uno.frontal.donnees;

import ca.ntro.app.frontend.ViewData;
import mon_uno.commun.monde2d.MondeUno2d;
import mon_uno.frontal.vues.VueSons;

public class DonneesVueSons implements ViewData{

	
	private MondeUno2d mondeUno2d = new MondeUno2d();
	private String sonsCourant = "0";
	
	
	public void afficherSur(VueSons vueSons) {
		vueSons.viderCanvas();
		vueSons.afficherSons2d(mondeUno2d);
		//vueSons.afficherImagesparSeconde("Play: " +sonsCourant);
	}


	public void reagirTempsQuiPasse(double elapsedTime) {
			mondeUno2d.onTimePasses(elapsedTime);
	}
}
