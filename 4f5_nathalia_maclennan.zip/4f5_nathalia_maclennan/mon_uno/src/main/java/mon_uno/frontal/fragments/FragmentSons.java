package mon_uno.frontal.fragments;

import ca.ntro.app.NtroApp;
import ca.ntro.app.fx.controls.ResizableAvatar;
import ca.ntro.app.views.ViewFragmentFx;
import ca.ntro.core.initialization.Ntro;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import mon_uno.commun.messages.MsgRetirerSon;
import mon_uno.frontal.evenements.EvtAfficherSons;
import mon_uno.frontal.evenements.EvtJouerSon;
import javafx.scene.media.AudioClip;
public class FragmentSons extends ViewFragmentFx {


	@FXML
	private Button boutonRetirerSon;

	@FXML
	private Label labelNomPremierSon;
	
	@FXML
	private Label labelTemps;
	@FXML 
	private ResizableAvatar music;
	@FXML
	private Button boutonPlay;

	private String idSon;

	@Override
	public void initialiser() {
		// TODO Auto-generated method stub
		Ntro.assertNotNull("labelNomPremierSon", labelNomPremierSon);
		Ntro.assertNotNull("labelTemps", labelTemps);
		Ntro.assertNotNull("boutonRetirerSon", boutonRetirerSon);
		Ntro.assertNotNull(music);
		music.setImage(new Image("/son.png"));
		music.setBackgroundColor(Color.WHITE);
		playSons();


		//installerJouerSons();

	}

//	private void installerJouerSons() {
//		EvtAfficherSons evtNtro = NtroApp.newEvent(EvtAfficherSons.class);
//
//		boutonAjouter.setOnAction(evtFx -> {
//
//			evtNtro.trigger();
//		});
//	}
	private AudioClip sonEffect = new AudioClip(FragmentSons.class.getResource("/test.wav").toString());
	public void afficherNomPremierSon(String nomPremierSon) {
		labelNomPremierSon.setText(nomPremierSon);
	}
	
	public void afficherTemps(String temps) {
		labelTemps.setText(temps);
	}
	private void jouerSon() {
		sonEffect.play();
	}
	private void playSons() {
		EvtJouerSon evtNtro = NtroApp.newEvent(EvtJouerSon.class);
		
		boutonPlay.setOnAction(evtFx ->{
			jouerSon();
		});
	}
	public void memoriserIdSon(String idSon) {
		this.idSon = idSon;
		installerMsgRetirerSon(idSon);
	}

	protected void installerMsgRetirerSon(String idSon) {
		MsgRetirerSon msgRetirerSon = NtroApp.newMessage(MsgRetirerSon.class);
		msgRetirerSon.setIdSon(idSon);

		boutonRetirerSon.setOnAction(evtFx -> {
			msgRetirerSon.send();
		});
	}

}
