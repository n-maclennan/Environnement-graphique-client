package mon_uno.frontal.taches;

import static ca.ntro.app.tasks.frontend.FrontendTasks.*;

import ca.ntro.app.frontend.ViewLoader;
import ca.ntro.app.services.Window;
import ca.ntro.app.tasks.frontend.FrontendTasks;
import mon_uno.frontal.fragments.FragmentSons;
import mon_uno.frontal.vues.VueParametres;
import mon_uno.frontal.vues.VueRacine;
import mon_uno.frontal.vues.VueSons;

public class Initialisation {

    public static void creerTaches(FrontendTasks tasks) {

        tasks.taskGroup("Initialisation")

             .andContains(subTasks -> {

                
                creerVueRacine(subTasks);

                installerVueRacine(subTasks);

                afficherFenetre(subTasks);
                
                creerVueParametre(subTasks);
                
                installerVueParametre(subTasks);
                
                creerVueSons(subTasks);
                
                //installerSons(subTasks);
             });
    }

	private static void afficherFenetre(FrontendTasks subTasks) {

		subTasks.task("afficherFenetre").waitsFor(window())

				.thenExecutes(inputs -> {

					Window window = inputs.get(window());
					window.show();
				});
	}

    private static void creerVueRacine(FrontendTasks tasks) {

        tasks.task(create(VueRacine.class))

             .waitsFor(viewLoader(VueRacine.class))

             .thenExecutesAndReturnsValue(inputs -> {

                 ViewLoader<VueRacine> viewLoader = inputs.get(viewLoader(VueRacine.class));

                 VueRacine vueRacine = viewLoader.createView();

                 return vueRacine;
             });
    }

    private static void installerVueRacine(FrontendTasks tasks) {

        tasks.task("installerVueRacine")

              .waitsFor(window())

              .waitsFor(created(VueRacine.class))

              .thenExecutes(inputs -> {

                  VueRacine vueRacine = inputs.get(created(VueRacine.class));
                  Window    window    = inputs.get(window());

                  window.installRootView(vueRacine);
              });
    }
    private static void creerVueParametre(FrontendTasks tasks) {

        tasks.task(create(VueParametres.class))

             .waitsFor(viewLoader(VueParametres.class))
             
             .waitsFor(viewLoader(FragmentSons.class))

             .thenExecutesAndReturnsValue(inputs -> {

                 ViewLoader<VueParametres> viewLoader = inputs.get(viewLoader(VueParametres.class));
                 
                 ViewLoader<FragmentSons> viewLoaderSons = inputs.get(viewLoader(FragmentSons.class));


                 VueParametres vueParametres = viewLoader.createView();
                 
                 vueParametres.setViewLoaderSons(viewLoaderSons);

                 return vueParametres;
             });
    }

    private static void installerVueParametre(FrontendTasks tasks) {

        tasks.task("installerVueParametre")

              .waitsFor(created(VueRacine.class))

              .waitsFor(created(VueParametres.class))

              .thenExecutes(inputs -> {

                  VueRacine      vueRacine      = inputs.get(created(VueRacine.class));
                  VueParametres vueParametres = inputs.get(created(VueParametres.class));

                  vueRacine.afficherSousVue(vueParametres);

              });
    }
    private static void creerVueSons(FrontendTasks tasks) {

        tasks.task(create(VueSons.class))

             .waitsFor(viewLoader(VueSons.class))

             .thenExecutesAndReturnsValue(inputs -> {

                 ViewLoader<VueSons> viewLoader = inputs.get(viewLoader(VueSons.class));

                 VueSons vueSons = viewLoader.createView();

                 return vueSons;
             });
    }
   
    
}
