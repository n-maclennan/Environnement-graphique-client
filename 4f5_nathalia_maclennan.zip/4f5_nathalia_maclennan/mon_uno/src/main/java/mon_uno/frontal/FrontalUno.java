package mon_uno.frontal;

import ca.ntro.app.NtroApp;
import ca.ntro.app.frontend.FrontendFx;
import ca.ntro.app.frontend.ViewRegistrarFx;
import ca.ntro.app.frontend.events.EventRegistrar;
import ca.ntro.app.tasks.frontend.FrontendTasks;
import mon_uno.frontal.donnees.DonneesVueSons;
import mon_uno.frontal.evenements.EvtAfficherParametres;
import mon_uno.frontal.evenements.EvtAfficherSons;
import mon_uno.frontal.fragments.FragmentSons;
import mon_uno.frontal.taches.AfficherAcceuilSons;
import mon_uno.frontal.taches.AfficherSons;
import mon_uno.frontal.taches.Initialisation;
import mon_uno.frontal.taches.Navigation;
import mon_uno.frontal.vues.VueParametres;
import mon_uno.frontal.vues.VueRacine;
import mon_uno.frontal.vues.VueSons;

public class FrontalUno implements FrontendFx {

	@Override
	public void createTasks(FrontendTasks tasks) {

		Initialisation.creerTaches(tasks);
		AfficherSons.creerTaches(tasks);
		Navigation.creerTaches(tasks);
		AfficherAcceuilSons.creerTaches(tasks);

	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub

	}

	@Override
	public void registerEvents(EventRegistrar registrar) {
		registrar.registerEvent(EvtAfficherSons.class);
		registrar.registerEvent(EvtAfficherParametres.class);
	}

	@Override
	public void registerViews(ViewRegistrarFx registrar) {

		registrar.registerView(VueRacine.class, "/racine.xml");
		registrar.registerView(VueParametres.class, "/parametres.xml");
		registrar.registerView(VueSons.class,"/son.xml");
		// registrar.registerStylesheet("/dev.css");
		registrar.registerStylesheet("/prod.css");
		registrar.registerDefaultResources("/chaines_fr.properties");
		registrar.registerResources(NtroApp.locale("en"), "/chaines_en.properties");
		registrar.registerResources(NtroApp.locale("es"), "/chaines_es.properties");
		registrar.registerFragment(FragmentSons.class,"/fragments/sonnerie.xml");
		registrar.registerViewData(DonneesVueSons.class);

	}

}
