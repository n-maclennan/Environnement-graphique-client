package mon_uno.frontal.vues;

import java.net.URL;
import java.util.ResourceBundle;

import ca.ntro.app.NtroApp;
import ca.ntro.app.views.ViewFx;
import ca.ntro.core.initialization.Ntro;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import mon_uno.commun.monde2d.MondeUno2d;
import mon_uno.frontal.controles.CanvasSons;
import mon_uno.frontal.evenements.EvtAfficherParametres;

public class VueSons extends ViewFx {

	@FXML
	private Button bouttonQuitter;

	@FXML
	private CanvasSons canvasSons;

	@Override
	public void initialiser() {
		Ntro.assertNotNull("bouttonQuitter", bouttonQuitter);
		Ntro.assertNotNull(canvasSons);
		installerEvtAfficherParametres();
	}

	private void installerEvtAfficherParametres() {
		EvtAfficherParametres evtNtro = NtroApp.newEvent(EvtAfficherParametres.class);

		bouttonQuitter.setOnAction(evtFx -> {

			evtNtro.trigger();
		});
	}

	public void viderCanvas() {
		canvasSons.clearCanvas();
	}

	public void afficherSons2d(MondeUno2d mondeUno2d) {
		mondeUno2d.drawOn(canvasSons);

	}

	public void afficherImagesparSeconde(String string) {
		
	}

}
