package mon_uno.frontal.taches;

import static ca.ntro.app.tasks.frontend.FrontendTasks.*;

import ca.ntro.app.tasks.frontend.FrontendTasks;
import ca.ntro.core.clock.Tick;
import mon_uno.frontal.donnees.DonneesVueSons;
import mon_uno.frontal.vues.VueSons;

public class AfficherAcceuilSons {

	public static void creerTaches(FrontendTasks tasks) {

		creerDonneesVueSons(tasks);
		tasks.taskGroup("AfficherSons")

				.waitsFor(created(DonneesVueSons.class))

				.andContains(subTasks -> {

					prochaineImageSons(subTasks);

				});
	}

	private static void creerDonneesVueSons(FrontendTasks tasks) {
		tasks.task(create(DonneesVueSons.class))

				.waitsFor("Initialisation")

				.executesAndReturnsCreatedValue(inputs -> {

					return new DonneesVueSons();
				});
	}

	private static void prochaineImageSons(FrontendTasks subTasks) {

		subTasks.task("prochaineImageSons")

				.waitsFor(clock().nextTick())

				.thenExecutes(inputs -> {
					
					Tick             tick             = inputs.get(clock().nextTick());
					
					DonneesVueSons donneesVueSons = inputs.get(created(DonneesVueSons.class));
					VueSons vueSons = inputs.get(created(VueSons.class));
					donneesVueSons.reagirTempsQuiPasse(tick.elapsedTime());
					donneesVueSons.afficherSur(vueSons);

				});
	}
}
