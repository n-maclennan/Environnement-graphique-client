package mon_uno.frontal.evenements;

import ca.ntro.app.frontend.events.EventNtro;

public class EvtAfficherSons extends EventNtro {
	

}
