package mon_uno.frontal.taches;

import static ca.ntro.app.tasks.frontend.FrontendTasks.*;
import ca.ntro.app.tasks.frontend.FrontendTasks;
import ca.ntro.core.reflection.observer.Modified;
import mon_uno.commun.modeles.ModeleParametres;
import mon_uno.frontal.vues.VueParametres;

public class AfficherSons {
	public static void creerTaches(FrontendTasks tasks) {

		tasks.taskGroup("AfficherSons")

				.waitsFor("Initialisation")

				.andContains(subTasks -> {

					// ajouter l'appel
					afficherSons(subTasks);

				});
	}

	private static void afficherSons(FrontendTasks tasks) {

		tasks.task("afficherSons")

				.waitsFor(modified(ModeleParametres.class))

				.executes(inputs -> {

					VueParametres vueParametres = inputs.get(created(VueParametres.class));
					Modified<ModeleParametres> parametres = inputs.get(modified(ModeleParametres.class));

					ModeleParametres ancienParametres = parametres.previousValue();
					ModeleParametres actuelParametres = parametres.currentValue();
					actuelParametres.afficherSur(vueParametres);

				});
	}
}
