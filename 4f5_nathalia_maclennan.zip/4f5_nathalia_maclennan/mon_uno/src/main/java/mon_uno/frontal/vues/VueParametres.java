package mon_uno.frontal.vues;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import ca.ntro.app.NtroApp;
import ca.ntro.app.frontend.ViewLoader;
import ca.ntro.app.fx.controls.ResizableAvatar;
import ca.ntro.app.views.ViewFx;
import ca.ntro.core.initialization.Ntro;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import mon_uno.commun.messages.MsgAjouterSons;
import mon_uno.commun.messages.MsgAjouterTemps;
import mon_uno.commun.modeles.ModeleParametres;
import mon_uno.commun.valeurs.Sonneries;
import mon_uno.commun.valeurs.Sons;
import mon_uno.commun.valeurs.Temps;
import mon_uno.frontal.evenements.EvtAfficherParametres;
import mon_uno.frontal.evenements.EvtAfficherSons;
import mon_uno.frontal.evenements.EvtJouerSon;
import mon_uno.frontal.fragments.FragmentSons;
import mon_uno.maquettes.MaquetteSons;
import mon_uno.maquettes.MaquetteTemps;
//import javafx.scene.media.AudioClip;
public class VueParametres extends ViewFx {
	@FXML
	private Label labelParametres;
	@FXML
	private Button boutonAcceuil;
	@FXML
	private Button boutonAjouter;
	//@FXML
	private Button boutonModifier;
	@FXML
	private VBox conteneurParametres;
	@FXML
	private Label labelSons;  
	
	@FXML
	private Label labelTemps;
	
	@FXML 
	private ResizableAvatar son;
	
	@FXML
	private TextField modifier;
	
	
	


	@Override
	public void initialiser() {

		Ntro.assertNotNull("boutonAcceuil", boutonAcceuil);
		Ntro.assertNotNull("conteneurParametres", conteneurParametres);
		son.setImage(new Image("/sol.png"));
		son.setBackgroundColor(Color.WHITE);

		installerMsgAjouterSons();
		installerJouerSons();
		


	}

	
	//private AudioClip sonEffect = new AudioClip(VueParametres.class.getResource("/soundeffect.wav").toString());
	private ViewLoader<FragmentSons> viewLoaderSons;

	public ViewLoader<FragmentSons> getViewLoaderSons() {
		return viewLoaderSons;
	}

	public void setViewLoaderSons(ViewLoader<FragmentSons> viewLoaderSons) {
		this.viewLoaderSons = viewLoaderSons;
	}

	public void afficher(ModeleParametres modele) {

		List<Sonneries> lesSons = modele.getLesSons();

	}
//	private void jouerSon() {
//		sonEffect.play();
//	}

	private void installerMsgAjouterSons() {
		MsgAjouterSons msgAjouterSons = NtroApp.newMessage(MsgAjouterSons.class);
		MsgAjouterTemps msgAjouterTemps = NtroApp.newMessage(MsgAjouterTemps.class);

		boutonAjouter.setOnAction(evtFx -> {
			
			msgAjouterSons.setPremierSon(MaquetteSons.sonCourant());
			msgAjouterSons.setTempsIni(MaquetteTemps.tempsCourant());
			msgAjouterSons.send();
			msgAjouterTemps.setTemps(MaquetteTemps.tempsCourant());
			msgAjouterTemps.send();
 
			MaquetteSons.prochainSon();
		});
	}
//	private void playSons() {
//		EvtJouerSon evtNtro = NtroApp.newEvent(EvtJouerSon.class);
//		
//		boutonModifier.setOnAction(evtFx ->{
//			jouerSon();
//		});
//	}
	
	private void installerJouerSons() {
		EvtAfficherSons evtNtro = NtroApp.newEvent(EvtAfficherSons.class);

		boutonAcceuil.setOnAction(evtFx -> {

			evtNtro.trigger();
		});
	}
	 public void ajouterSons(Sonneries sons) {
         FragmentSons fragment = sons.creerFragment(viewLoaderSons);
         sons.afficherSur(fragment);

         conteneurParametres.getChildren().add(fragment.rootNode());
     }
     
     // ajouter
     public void viderListeRendezVous() {
    	 conteneurParametres.getChildren().clear();
     }
     
    

}
