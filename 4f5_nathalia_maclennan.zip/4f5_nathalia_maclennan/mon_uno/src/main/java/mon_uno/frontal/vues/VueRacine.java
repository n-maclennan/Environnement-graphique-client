package mon_uno.frontal.vues;



import ca.ntro.app.views.ViewFx;
import javafx.scene.layout.Pane;

public class VueRacine extends ViewFx {


	public void afficherSousVue(ViewFx sousVue) {

		Pane racineSousVue = sousVue.rootNode();

		rootNode().getChildren().clear();
		rootNode().getChildren().add(racineSousVue);
	}

	@Override
	public void initialiser() {
		// TODO Auto-generated method stub
		
	}

}
