package mon_uno.frontal.taches;

import static ca.ntro.app.tasks.frontend.FrontendTasks.*;

import ca.ntro.app.frontend.ViewLoader;
import ca.ntro.app.tasks.frontend.FrontendTasks;
import mon_uno.frontal.evenements.EvtAfficherParametres;
import mon_uno.frontal.evenements.EvtAfficherSons;
import mon_uno.frontal.vues.VueParametres;
import mon_uno.frontal.vues.VueRacine;
import mon_uno.frontal.vues.VueSons;

public class Navigation {

	public static void creerTaches(FrontendTasks tasks) {

		tasks.taskGroup("Navigation")

				.waitsFor("Initialisation")

				.andContains(subTasks -> {
					
					afficherVueSons(subTasks);
					afficherParametres(subTasks);
					
	                
					

				});
	}

	private static void afficherParametres(FrontendTasks tasks) {

		tasks.task("afficherVueParametres")

				.waitsFor(event(EvtAfficherParametres.class))

				.thenExecutes(inputs -> {

					VueRacine vueRacine = inputs.get(created(VueRacine.class));
					VueParametres vueParametres = inputs.get(created(VueParametres.class));

					vueRacine.afficherSousVue(vueParametres);

				});
	}

	private static void afficherVueSons(FrontendTasks tasks) {

		tasks.task("afficherVueSons")

				//.waitsFor(created(VueSons.class))

				.waitsFor(event(EvtAfficherSons.class))

				.thenExecutes(inputs -> {

					VueRacine vueRacine = inputs.get(created(VueRacine.class));
					VueSons vueSons = inputs.get(created(VueSons.class));

					vueRacine.afficherSousVue(vueSons);
				});
	}
	

	    private static void installerSons(FrontendTasks tasks) {

	        tasks.task("installerSons")

	              .waitsFor(created(VueRacine.class))

	              .waitsFor(created(VueSons.class))

	              .thenExecutes(inputs -> {

	                  VueRacine      vueRacine      = inputs.get(created(VueRacine.class));
	                  VueSons vueSons = inputs.get(created(VueSons.class));

	                  vueRacine.afficherSousVue(vueSons);

	              });
	    }
}
