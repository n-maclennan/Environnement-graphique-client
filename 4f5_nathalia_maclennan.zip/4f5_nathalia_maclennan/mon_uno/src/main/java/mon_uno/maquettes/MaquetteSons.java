package mon_uno.maquettes;

import java.util.List;

import ca.ntro.core.initialization.Ntro;
import mon_uno.commun.valeurs.Sons;


public class MaquetteSons {

	public static boolean modeTest = true;

	private static Sons sonCourant = sonAleatoire();

	public static boolean siSonLocal(Sons son) {
		boolean siLocal = false;

		if (modeTest) {

			siLocal = true;

		} else if (sonCourant.equals(son)) {

			siLocal = true;
		}

		return siLocal;
	}

	public static Sons sonCourant() {
		return sonCourant;
	}

	public static void prochainSon() {
		sonCourant = eviterRepetitionDeSonnerie(sonAleatoire());
	}

	private static Sons sonAleatoire() {
		Sons son = new Sons();

		son.setId(idAleatoire());
		son.setSonnerie(sonnerieAleatoire());

		return son;
	}

	private static Sons eviterRepetitionDeSonnerie(Sons sonAleatoire) {

		while (sonAleatoire.getSonnerie().equals(sonCourant.getSonnerie())) {

			sonAleatoire.setSonnerie(sonnerieAleatoire());
		}

		return sonAleatoire;
	}

	private static String idAleatoire() {
		return Ntro.random().nextId(4);
	}

	private static String sonnerieAleatoire() {

		List<String> choixDeSonnerie = List.of("motor.wav", "cards.wav", "jengo.wav", "jurassic.wav", "jumanji.wav",
				"monopolio.wav", "town.wav", "dice.wav", "rainforest.wav", "beachday.wav", "latino.wav", "maracas.wav",
				"mix.wav");

		return Ntro.random().choice(choixDeSonnerie);
	}

	public static void initialiser(String[] args) {
		String sonnerie = null;

		if (args.length > 0) {

			sonnerie = args[0];
			modeTest = false;

		} else {

			sonnerie = sonnerieAleatoire();

		}

		sonCourant = new Sons(idAleatoire(), sonnerie);
	}

}
