package mon_uno.maquettes;

import java.util.List;

import ca.ntro.core.initialization.Ntro;
import mon_uno.commun.valeurs.Temps;

public class MaquetteTemps {
	
	public static boolean modeTest = true;

	private static Temps tempsCourant = tempsAleatoire();

	public static boolean siTempsLocal(Temps temps) {
		boolean siLocal = false;

		if (modeTest) {

			siLocal = true;

		} else if (tempsCourant.equals(temps)) {

			siLocal = true;
		}

		return siLocal;
	}

	public static Temps tempsCourant() {
		return tempsCourant;
	}

	public static void prochainSon() {
		tempsCourant = eviterRepetitionDeTemps(tempsAleatoire());
	}

	private static Temps tempsAleatoire() {
		Temps temps = new Temps();

		temps.setHeures(heuresAleatoire());
		temps.setMinutes(minutesAleatoire());
		temps.setSecondes(secondesAleatoire());

		return temps;
	}

	private static Temps eviterRepetitionDeTemps(Temps tempsAleatoire) {

		while (tempsAleatoire.getHeures().equals(tempsCourant.getHeures())) {

			tempsAleatoire.setHeures(heuresAleatoire());
		}

		return tempsAleatoire;
	}

	private static String heuresAleatoire() {
		int valeurTemp = Ntro.random().nextInt(1);
		return String.valueOf(valeurTemp);
	}

	private static String minutesAleatoire() {

		int valeurTemp = Ntro.random().nextInt(60);
		return String.valueOf(valeurTemp);
	}	
	private static String secondesAleatoire() {
		int valeurTemp = Ntro.random().nextInt(60);
		return String.valueOf(valeurTemp);
	}

	public static void initialiser(String[] args) {
		String temps = null;

		if (args.length > 0) {

			temps = args[0];
			modeTest = false;

		} else {

			temps = heuresAleatoire();

		}

		tempsCourant = new Temps(temps,minutesAleatoire(),secondesAleatoire() );
	}


}
