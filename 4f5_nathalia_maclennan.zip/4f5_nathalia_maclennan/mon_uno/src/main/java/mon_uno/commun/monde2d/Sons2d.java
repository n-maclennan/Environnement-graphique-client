package mon_uno.commun.monde2d;

import ca.ntro.app.fx.controls.ResizableWorld2dCanvasFx;
import ca.ntro.app.fx.controls.World2dMouseEventFx;
import ca.ntro.core.initialization.Ntro;
import javafx.scene.image.Image;
import javafx.scene.shape.ArcType;
import mon_uno.frontal.vues.VueParametres;
import javafx.scene.media.AudioClip;

public class Sons2d extends ObjetUno2d {

	private static final double EPSILON = 1;
	private Image image = new Image("/sol.png");
	private AudioClip sonEffect = new AudioClip(Sons2d.class.getResource("/soundeffect.wav").toString());

	public Sons2d() {
		super();
	}

	private void jouerSon() {
		sonEffect.play();
	}

	@Override
	public void initialize() {
		setWidth(80);
		setHeight(80);
		setTopLeftX(100);
		setTopLeftY(100);

		setSpeedX(100 + Ntro.random().nextInt(100));
		setSpeedY(100 + Ntro.random().nextInt(100));
	}

	@Override
	public void drawOn(ResizableWorld2dCanvasFx canvas) {
		canvas.drawOnWorld(gc -> {

			gc.drawImage(image, getTopLeftX(), getTopLeftY(), getWidth(), getHeight());
		});
	}

	@Override
	protected boolean onMouseEvent(World2dMouseEventFx mouseEvent) {
		return false;
	}

	@Override
	public String id() {
		return "sons";
	}

	@Override
	public void onTimePasses(double secondsElapsed) {
		super.onTimePasses(secondsElapsed);

		if (balleFrappeMurGauche()) {

			balleRebondiSurMurGauche();

		} else if (balleFrappeMurDroit()) {

			balleRebondiSurMurDroit();

		} else if (balleFrappePlafond()) {

			balleRebondiSurPlafond();

		} else if (balleFrappePlancher()) {

			balleRebondiSurPlancher();
		}

	}

	private boolean balleFrappePlancher() {
		return collidesWith(0, getWorld2d().getHeight(), getWorld2d().getWidth(), 1);
	}

	private boolean balleFrappePlafond() {
		return collidesWith(0, 0, getWorld2d().getWidth(), 1);
	}

	private boolean balleFrappeMurDroit() {
		return collidesWith(getWorld2d().getWidth(), 0, 1, getWorld2d().getHeight());
	}

	private boolean balleFrappeMurGauche() {
		return collidesWith(0, 0, 1, getWorld2d().getHeight());
	}

	private void balleRebondiSurPlancher() {
		setTopLeftY(getWorld2d().getHeight() - this.getHeight() - EPSILON);
		setSpeedY(-getSpeedY());
		jouerSon();
	}

	private void balleRebondiSurPlafond() {
		setTopLeftY(0 + EPSILON);
		setSpeedY(-getSpeedY());
		jouerSon();
	}

	private void balleRebondiSurMurDroit() {
		setTopLeftX(getWorld2d().getWidth() - this.getWidth() - EPSILON);
		setSpeedX(-getSpeedX());
		jouerSon();
	}

	private void balleRebondiSurMurGauche() {
		setTopLeftX(0 + EPSILON);
		setSpeedX(-getSpeedX());
		jouerSon();
	}

}
