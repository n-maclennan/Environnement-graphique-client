package mon_uno.commun.modeles.valeurs;

import ca.ntro.app.models.ModelValue;

public class Sonneries implements ModelValue {
	private String idSonnerie;

	public String getIdSonnerie() {
		return idSonnerie;
	}

	public void setIdSonnerie(String idSonnerie) {
		this.idSonnerie = idSonnerie;
	}
	
	public Sons getPremierSon() {
		return premierSon;
	}

	public void setPremierSon(Sons premierSon) {
		this.premierSon = premierSon;
	}

	private Sons premierSon;
	
	public Sonneries() {
		
	}

	public Sonneries(String id, Sons premierSon) {
		setIdSonnerie(id);
		setPremierSon(premierSon);
		
	}
	@Override
	public String toString() {
		return premierSon.toString();
	}
}
