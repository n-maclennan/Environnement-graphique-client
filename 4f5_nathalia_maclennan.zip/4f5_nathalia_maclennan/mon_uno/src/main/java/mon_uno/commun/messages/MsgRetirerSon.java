package mon_uno.commun.messages;

import ca.ntro.app.messages.MessageNtro;
import mon_uno.commun.modeles.ModeleParametres;

public class MsgRetirerSon extends MessageNtro {

	private String idSon;

	public String getIdSon() {
		return idSon;
	}

	public void setIdSon(String idSon) {
		this.idSon = idSon;
	}
	

	public void retirerDe(ModeleParametres parametres) {
		parametres.retirerSon(idSon);
	}
}
