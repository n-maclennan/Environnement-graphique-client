package mon_uno.commun.messages;

import ca.ntro.app.messages.MessageNtro;
import mon_uno.commun.modeles.ModeleParametres;
import mon_uno.commun.valeurs.Sons;
import mon_uno.commun.valeurs.Temps;

public class MsgAjouterSons extends MessageNtro {
	
	private Sons premierSon;
	private Temps temps;
	
	public Temps getTemps() {
		return temps;
	}

	public void setTemps(Temps temps) {
		this.temps = temps;
	}

	public MsgAjouterSons() {
		
	}

	public Sons getPremierSon() {
		return premierSon;
	}

	public void setPremierSon(Sons premierSon) {
		this.premierSon = premierSon;
	}
	
	public void ajouterA(ModeleParametres parametres) {
		parametres.ajouterSons(premierSon,temps);
	}

	public void setTempsIni(Temps tempsCourant) {
		this.temps = tempsCourant;
		
	}

}
