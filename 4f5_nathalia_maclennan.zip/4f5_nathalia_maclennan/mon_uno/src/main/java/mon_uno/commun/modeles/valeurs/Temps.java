package mon_uno.commun.modeles.valeurs;

import ca.ntro.app.models.ModelValue;

public class Temps implements ModelValue {
	
	private String heures;
	private String minutes;
	private String secondes;
	
	public String getHeures() {
		return heures;
	}

	public void setHeures(String heures) {
		this.heures = heures;
	}

	public String getMinutes() {
		return minutes;
	}

	public void setMinutes(String minutes) {
		this.minutes = minutes;
	}

	public String getSecondes() {
		return secondes;
	}

	public void setSecondes(String secondes) {
		this.secondes = secondes;
	}

	public Temps() {
		
	}
	
	public Temps(String heures, String minutes, String secondes) {
		setHeures(heures);
		setMinutes(minutes);
		setSecondes(secondes);
	}
	
	@Override
	public String toString() {
		return heures.toString()+":"+ minutes.toString()+":"+secondes.toString();
	}

}
