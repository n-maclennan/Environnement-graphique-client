package mon_uno.commun.valeurs;

import ca.ntro.app.frontend.ViewLoader;
import ca.ntro.app.models.ModelValue;
import mon_uno.frontal.fragments.FragmentSons;


public class Sonneries implements ModelValue {
	private String idSonnerie;
	
	private Temps temps;
	
	public Temps getTemps() {
		return temps;
	}

	public void setTemps(Temps temps) {
		this.temps = temps;
	}

	public String getIdSonnerie() {
		return idSonnerie;
	}

	public void setIdSonnerie(String idSonnerie) {
		this.idSonnerie = idSonnerie;
	}

	public Sons getPremierSon() {
		return premierSon;
	}

	public void setPremierSon(Sons premierSon) {
		this.premierSon = premierSon;
	}

	private Sons premierSon;

	public Sonneries() {

	}
	

	public Sonneries(String id, Sons premierSon, Temps temps) {
		setIdSonnerie(id);
		setPremierSon(premierSon);
		setTemps(temps);

	}

	@Override
	public String toString() {
		return nomSons();
	}
	
	public String nomSons() {
		return idSonnerie +"."+" " + premierSon.getSonnerie();
	}
	public String temps() {
		return temps.toString();
	}

	public FragmentSons creerFragment(ViewLoader<FragmentSons> viewLoaderSons) {

		return viewLoaderSons.createView();
	}

	public void afficherSur(FragmentSons fragmentSons) {
		fragmentSons.afficherNomPremierSon(nomSons());
		fragmentSons.afficherTemps(temps());
		fragmentSons.memoriserIdSon(idSonnerie);

	}
}
