package mon_uno.commun.monde2d;

import ca.ntro.app.fx.world2d.Object2dFx;

public abstract class ObjetUno2d extends Object2dFx<MondeUno2d> {

}
