package mon_uno.commun;

import ca.ntro.app.ServerRegistrar;
import ca.ntro.app.messages.MessageRegistrar;
import ca.ntro.app.models.ModelRegistrar;
import mon_uno.commun.messages.MsgAjouterSons;
import mon_uno.commun.messages.MsgAjouterTemps;
import mon_uno.commun.modeles.ModeleParametres;
import mon_uno.commun.valeurs.Sonneries;
import mon_uno.commun.valeurs.Sons;
import mon_uno.commun.valeurs.Temps;

public class Declarations {

	public static void declarerMessages(MessageRegistrar registrar) {
		registrar.registerMessage(MsgAjouterSons.class);
		registrar.registerMessage(MsgAjouterTemps.class);
	}

	public static void declarerModeles(ModelRegistrar registrar) {
		registrar.registerModel(ModeleParametres.class);
		registrar.registerValue(Sons.class);
		registrar.registerValue(Sonneries.class);
		registrar.registerValue(Temps.class);
	}

	public static void declarerServeur(ServerRegistrar registrar) {
		registrar.registerName("localhost");
		registrar.registerPort(8002);
	}

}
