package mon_uno.commun.modeles;

import java.util.ArrayList;
import java.util.List;

import ca.ntro.app.models.Model;
import ca.ntro.app.models.WatchJson;
import ca.ntro.app.models.WriteObjectGraph;
import mon_uno.commun.valeurs.Sonneries;
import mon_uno.commun.valeurs.Sons;
import mon_uno.commun.valeurs.Temps;
import mon_uno.frontal.vues.VueParametres;

public class ModeleParametres implements Model, WatchJson, WriteObjectGraph {
	private long prochainId = 1;


	public long getProchainId() {
		return prochainId;
	}

	public void setProchainId(long prochainId) {
		this.prochainId = prochainId;
	}

	public ModeleParametres() {

	}

	private List<Sonneries> lesSons = new ArrayList<>();

	public List<Sonneries> getLesSons() {
		return lesSons;
	}


	public void setLesSons(List<Sonneries> lesSons) {
		this.lesSons = lesSons;
	}

	public void afficherSur(VueParametres vueParametres) {

		 // ajouter
        vueParametres.viderListeRendezVous();
        
        // ajouter
        for(Sonneries sons : lesSons) {
            
            vueParametres.ajouterSons(sons);
        }
	}


	public void ajouterSons(Sons premierSon, Temps temps) {

		String id = genererId();

		Sonneries son = new Sonneries(id, premierSon, temps);

		lesSons.add(son);
	}

	private String genererId() {

		String id = String.valueOf(prochainId);
		prochainId++;

		return id;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		int numeroSon = 1;

		for (Sonneries son : lesSons) {

			builder.append(numeroSon);
			builder.append(". ");
			builder.append(son.toString());
			builder.append("\n");

			numeroSon++;
		}

		return builder.toString();
	}
	 public void retirerSon(String idSon) {
	        int indiceSon = -1;
	        
	        for(int i = 0; i < lesSons.size(); i++) {
	            if(lesSons.get(i).getIdSonnerie().equals(idSon)) {
	            	indiceSon = i;
	                break;
	            }
	        }
	        
	        if(indiceSon >= 0) {
	            lesSons.remove(indiceSon);
	        }
	    }
}
