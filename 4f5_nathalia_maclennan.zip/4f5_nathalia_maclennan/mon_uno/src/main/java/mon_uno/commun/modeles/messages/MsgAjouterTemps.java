package mon_uno.commun.modeles.messages;

import ca.ntro.app.messages.MessageNtro;
import mon_uno.commun.modeles.ModeleParametres;
import mon_uno.commun.valeurs.Sons;
import mon_uno.commun.valeurs.Temps;

public class MsgAjouterTemps extends MessageNtro{
	
	private Sons premierSon;
	public Sons getPremierSon() {
		return premierSon;
	}
	public void setPremierSon(Sons premierSon) {
		this.premierSon = premierSon;
	}

	private Temps temps;
	
	public MsgAjouterTemps() {
		
	}
	public Temps getTemps() {
		return temps;
	}

	public void setTemps(Temps temps) {
		this.temps = temps;
	}

	public void ajouterA(ModeleParametres parametres) {
		parametres.ajouterSons(premierSon,temps);
	}
	

}
