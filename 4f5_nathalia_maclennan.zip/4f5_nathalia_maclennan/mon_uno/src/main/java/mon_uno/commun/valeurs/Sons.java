package mon_uno.commun.valeurs;

import ca.ntro.app.frontend.ViewLoader;
import ca.ntro.app.models.ModelValue;
import mon_uno.frontal.fragments.FragmentSons;

public class Sons implements ModelValue {
	private String id;
	private String sonnerie;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSonnerie() {
		return sonnerie;
	}

	public void setSonnerie(String sonnerie) {
		this.sonnerie = sonnerie;
	}

	public Sons() {

	}

	public Sons(String id, String sonnerie) {
		setId(id);
		setSonnerie(sonnerie);
	}

	@Override
	public String toString() {
		return sonnerie.toString();
	}

	
}
