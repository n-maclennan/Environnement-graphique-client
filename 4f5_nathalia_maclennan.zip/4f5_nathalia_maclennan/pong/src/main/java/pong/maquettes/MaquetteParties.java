package pong.maquettes;

import java.util.List;

public class MaquetteParties {

    public static List<String> partieEnCours(){
        return List.of("aaaa","bbbb","cccc");
    }
}