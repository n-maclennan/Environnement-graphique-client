package pong.maquettes;
public enum Cadran {

    GAUCHE, DROITE, LES_DEUX;

}