package pong.dorsal.taches;
import static ca.ntro.app.tasks.backend.BackendTasks.*;

import ca.ntro.app.tasks.backend.BackendTasks;
import pong.commun.modeles.ModeleFileAttente;
import pong.commun.modeles.messages.MsgAjouterRendezVous;
import pong.commun.modeles.messages.MsgRetirerRendezVous;


public class ModifierFileAttente {
	 public static void creerTaches(BackendTasks tasks) {

	        tasks.taskGroup("ModifierFileAttente")

	             .waitsFor(model(ModeleFileAttente.class))

	             .andContains(subTasks -> {

	                // XXX: ajouter l'appel!
	                ajouterRendezVous(subTasks);
	                
	                retirerRendezVous(subTasks);

	              });
	    }

	    private static void ajouterRendezVous(BackendTasks subTasks) {
	        subTasks.task("ajouterRendezVous")

	             .waitsFor(message(MsgAjouterRendezVous.class))

	             .thenExecutes(inputs -> {

	                 MsgAjouterRendezVous msgAjouterRendezVous = inputs.get(message(MsgAjouterRendezVous.class));
	                 ModeleFileAttente    fileAttente          = inputs.get(model(ModeleFileAttente.class));

	                 // Prêt à ajouter un rendez-vous!
	                 msgAjouterRendezVous.ajouterA(fileAttente);

	             });
	    }
	    private static void retirerRendezVous(BackendTasks subTasks) {
	        subTasks.task("retirerRendezVous")

	             .waitsFor(message(MsgRetirerRendezVous.class))
	             
	             .thenExecutes(inputs -> {

	                 MsgRetirerRendezVous msgRetirerRendezVous = inputs.get(message(MsgRetirerRendezVous.class));
	                 ModeleFileAttente    fileAttente          = inputs.get(model(ModeleFileAttente.class));

	                 msgRetirerRendezVous.retirerDe(fileAttente);
	             });

	    }
}
