package pong.frontal.evenements;

import ca.ntro.app.frontend.events.EventNtro;
import pong.commun.modeles.valeurs.ActionJoueur;
import pong.frontal.donnees.DonneesVuePartie;

public class EvtActionJoueur extends EventNtro {

    private ActionJoueur action;

    // générer les méthodes get/set

    public ActionJoueur getAction() {
		return action;
	}

	public void setAction(ActionJoueur action) {
		this.action = action;
	}

	public EvtActionJoueur() {
    }

    public void appliquerA(DonneesVuePartie donneesVuePartie) {
        action.appliquerA(donneesVuePartie);
    }

	public void diffuserMsgActionAutreJoueur() {
		// TODO Auto-generated method stub
		
	}

}
