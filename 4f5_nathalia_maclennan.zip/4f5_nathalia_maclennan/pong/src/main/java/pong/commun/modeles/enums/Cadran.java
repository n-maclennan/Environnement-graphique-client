package pong.commun.modeles.enums;

public enum Cadran {
	GAUCHE, DROITE, LES_DEUX;
}
