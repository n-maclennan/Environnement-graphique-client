package pong.commun.modeles.monde2d;

import ca.ntro.app.fx.world2d.Object2dFx;

public abstract class ObjetPong2d extends Object2dFx<MondePong2d> {
}
