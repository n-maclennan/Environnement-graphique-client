package pong.commun.modeles.messages;

import ca.ntro.app.messages.MessageNtro;
import pong.frontal.donnees.DonneesVuePartie;

public class MsgActionAutreJoueur extends MessageNtro {

	public void appliquerA(DonneesVuePartie donneesVuePartie) {
		// TODO Auto-generated method stub
		
	}

}
