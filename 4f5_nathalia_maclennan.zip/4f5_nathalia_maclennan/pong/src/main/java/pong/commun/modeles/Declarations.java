package pong.commun.modeles;

import ca.ntro.app.ServerRegistrar;
import ca.ntro.app.messages.MessageRegistrar;
import ca.ntro.app.models.ModelRegistrar;
import pong.commun.modeles.messages.MsgAjouterPoint;
import pong.commun.modeles.messages.MsgAjouterRendezVous;
import pong.commun.modeles.messages.MsgRetirerRendezVous;
import pong.commun.modeles.monde2d.Balle2d;
import pong.commun.modeles.monde2d.MondePong2d;
import pong.commun.modeles.monde2d.ObjetPong2d;
import pong.commun.modeles.monde2d.Palette2d;
import pong.commun.modeles.valeurs.PartieEnCours;
import pong.commun.modeles.valeurs.RendezVous;
import pong.commun.modeles.valeurs.Usager;

public class Declarations {

	public static void declarerMessages(MessageRegistrar registrar) {
		registrar.registerMessage(MsgAjouterRendezVous.class);
		registrar.registerMessage(MsgRetirerRendezVous.class);
		registrar.registerMessage(MsgAjouterPoint.class);
	}

	public static void declarerModeles(ModelRegistrar registrar) {
		registrar.registerModel(ModeleFileAttente.class);
		registrar.registerModel(ModelePartie.class);
		registrar.registerValue(Usager.class);
		registrar.registerValue(RendezVous.class);
		registrar.registerValue(PartieEnCours.class);
		registrar.registerValue(MondePong2d.class);
		registrar.registerValue(ObjetPong2d.class);
		registrar.registerValue(Balle2d.class);
		registrar.registerValue(Palette2d.class);
	}

	public static void declarerServeur(ServerRegistrar registrar) {
		registrar.registerName("localhost");

		registrar.registerPort(8002);
	}

}
