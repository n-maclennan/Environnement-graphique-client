package pong.commun.modeles.messages;

public class MsgModifierInfoPartie {

}
