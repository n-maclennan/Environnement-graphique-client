package pong.commun.modeles.enums;

public enum Action {
	HAUT, BAS, ARRET;
}
